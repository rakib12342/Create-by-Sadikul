# Create by Sadikul — FB Page Creator helper

Android Studio starter project. It provides:
- English UI branded “Create by Sadikul”
- Quantity selector for 1–15 Pages
- Per-Page name and category
- Opens Facebook's Page creation page in the user's browser
- Copies the entered Page name and category to the clipboard
- Lets the user manually mark a Page as created

## Important limitation
This app does **not** automate Facebook Page creation and cannot verify whether Facebook successfully created a Page. The user signs in directly with Facebook and completes the Page creation flow there. It does not collect Facebook passwords, cookies, or session tokens. Fully automatic creation requires a supported Facebook integration and whatever access Facebook grants.

## Build APK
1. Install Android Studio and Android SDK 35.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
