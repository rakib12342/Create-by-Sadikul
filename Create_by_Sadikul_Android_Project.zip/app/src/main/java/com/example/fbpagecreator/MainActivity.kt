package com.example.fbpagecreator

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { CreatorScreen() } }
    }
}

@Composable
fun CreatorScreen() {
    val context = LocalContext.current
    var quantityText by remember { mutableStateOf("1") }
    val categoryOptions = listOf(
        "Business", "Brand", "Product/Service", "Shopping & Retail", "Local Service",
        "Restaurant", "Cafe", "Beauty, Cosmetic & Personal Care", "Health/Beauty",
        "Education", "School", "College & University", "Community", "Nonprofit Organization",
        "Entertainment", "Media/News Company", "Musician/Band", "Artist", "Digital Creator",
        "Blogger", "Personal Blog", "Gaming Video Creator", "Sports", "Travel",
        "Food & Beverage", "Clothing (Brand)", "Website", "Public Figure", "Other"
    )
    var names by remember { mutableStateOf(listOf("")) }
    var categories by remember { mutableStateOf(listOf("Digital Creator")) }
    var created by remember { mutableStateOf(setOf<Int>()) }
    var status by remember { mutableStateOf("Choose quantity, enter names, then open Facebook to create each Page.") }
    val quantity = quantityText.toIntOrNull()?.coerceIn(1, 15) ?: 1

    LaunchedEffect(quantity) {
        names = when {
            names.size < quantity -> names + List(quantity - names.size) { "" }
            names.size > quantity -> names.take(quantity)
            else -> names
        }
        categories = when {
            categories.size < quantity -> categories + List(quantity - categories.size) { "Digital Creator" }
            categories.size > quantity -> categories.take(quantity)
            else -> categories
        }
        created = created.filter { it < quantity }.toSet()
    }

    fun openFacebookCreate(index: Int) {
        val name = names.getOrElse(index) { "" }.trim()
        val category = categories.getOrElse(index) { "Digital Creator" }
        if (name.isBlank()) {
            status = "Enter a name for Page ${index + 1} first."
            return
        }
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Facebook Page details", "$name\n$category"))
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/pages/create"))
        try {
            context.startActivity(intent)
            status = "Facebook opened. Page name and category copied. Complete creation on Facebook, then return and mark it created."
        } catch (_: Exception) {
            status = "Could not open Facebook. Install/update a browser and try again."
        }
    }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("Create by Sadikul", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                Text("FB Page Creator", style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold)
                Text("Prepare and create Pages through Facebook", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                Card {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Facebook", fontWeight = FontWeight.SemiBold)
                        Text("This app does not collect Facebook passwords, cookies, or session tokens. Facebook opens separately for you to sign in and complete each Page creation.")
                        OutlinedButton(onClick = {
                            try {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/")))
                                status = "Facebook opened in your browser."
                            } catch (_: Exception) { status = "Could not open browser." }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Open Facebook") }
                    }
                }
            }
            item {
                Text("Number of Pages (1–15)", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(
                    value = quantityText,
                    onValueChange = { raw -> quantityText = raw.filter(Char::isDigit).take(2) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    supportingText = { Text("Choose between 1 and 15") }
                )
            }
            item { Text("Page details", fontWeight = FontWeight.SemiBold) }
            itemsIndexed(names) { index, name ->
                var expanded by remember { mutableStateOf(false) }
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Page ${index + 1}", fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = name,
                            onValueChange = { updated -> names = names.toMutableList().also { it[index] = updated } },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("Page name") }
                        )
                        Text("Category", style = MaterialTheme.typography.labelLarge)
                        Box {
                            OutlinedButton(onClick = { expanded = true }) { Text(categories.getOrElse(index) { "Digital Creator" }) }
                            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                categoryOptions.forEach { category ->
                                    DropdownMenuItem(text = { Text(category) }, onClick = {
                                        categories = categories.toMutableList().also { it[index] = category }
                                        expanded = false
                                    })
                                }
                            }
                        }
                        Button(onClick = { openFacebookCreate(index) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Open Facebook to create Page ${index + 1}")
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(if (index in created) "Marked as created" else "Not confirmed", color = if (index in created) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                            TextButton(onClick = {
                                created = if (index in created) created - index else created + index
                                status = if (index in created) "Page ${index + 1} marked as created by you." else "Page ${index + 1} marked as not created."
                            }) { Text(if (index in created) "Undo" else "I created this Page") }
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Text(status, modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
                }
                Text("${created.size} of $quantity marked as created by you. This is a manual confirmation; the app cannot independently verify Facebook creation.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
